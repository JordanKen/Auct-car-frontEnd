// Notification items
export interface Notification {
    icon?: string;
    color?: string;
    title: string;
    text: string;
    image?: string;
}
