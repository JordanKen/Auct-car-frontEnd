const tableData = [
  {
    id: 1,
    name: 'Orange Money',
    comment: 'string.............',
    percentage_fee: 1.25,
    fixed_fee: 1.5,
    how_to: 'bla bla bla bla bla',
    json_data: 'string',
    created_at: '31/11/2020',
    updated_at: '2018/07/29',
    thumb: 'thumbs',
    method_identifier_field__name: 'OM',
    is_active: 1
  },
  {
    id: 1,
    name: 'Orange Money',
    comment: 'string.............',
    percentage_fee: 1.25,
    fixed_fee: 1.5,
    how_to: 'bla bla bla bla bla',
    json_data: 'string',
    created_at: '31/11/2020',
    updated_at: '2018/07/29',
    thumb: 'thumbs',
    method_identifier_field__name: 'OM',
    is_active: 1
  },
];

export { tableData };
