import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profile3',
  templateUrl: './profile3.component.html',
  styleUrls: ['./profile3.component.scss']
})
export class Profile3Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
