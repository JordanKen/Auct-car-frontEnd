import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profile4',
  templateUrl: './profile4.component.html',
  styleUrls: ['./profile4.component.scss']
})
export class Profile4Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
