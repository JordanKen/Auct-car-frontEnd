// export layout related constants
export const LAYOUT_VERTICAL = 'vertical';

export const LAYOUT_HORIZONTAL = 'horizontal';

export const LAYOUT_WIDTH_FLUID = 'fluid';

export const LAYOUT_WIDTH_BOXED = 'boxed';

export const SIDEBAR_THEME_DEFAULT = 'vertical';

export const SIDEBAR_THEME_DARK = 'dark';

export const SIDEBAR_WIDTH_CONDENSED = 'condensed';



