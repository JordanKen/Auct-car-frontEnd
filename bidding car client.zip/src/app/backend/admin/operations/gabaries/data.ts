const tableData = [
  {
    id: 1,
    user_id: 2,
    send_id: 2,
    from_id: 2,
    transaction_state_id: 1,
    gross: 3,
    fee: 200,
    net: 1500,
    description: '',
    json_data: '',
    created_at: '31/11/2020',
    updated_at: '31/11/2020',
    currency_id: 3,
    currency_symbol: '$'
  },
  {
    id: 1,
    user_id: 2,
    send_id: 2,
    from_id: 2,
    transaction_state_id: 1,
    gross: 3,
    fee: 200,
    net: 1500,
    description: '',
    json_data: '',
    created_at: '31/11/2020',
    updated_at: '31/11/2020',
    currency_id: 3,
    currency_symbol: '$'
  },
];

export { tableData };
