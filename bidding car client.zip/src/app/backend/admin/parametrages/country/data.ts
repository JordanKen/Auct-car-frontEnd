const tableData = [
  {
    id: 1,
    code: '00237',
    name: 'cameroun',
    nicename: 'democratic republic of cameroun',
    iso3: 'iso/cmr',
    numcode: 237,
    prefix: 'cmr',
    created_at: '31/11/2020',
    updated_at: '2018/07/29',
    deleted_at: '2018/07/29'
  },
  {
    id: 2,
    code: '00237',
    name: 'cameroun',
    nicename: 'democratic republic of cameroun',
    iso3: 'iso/cmr',
    numcode: 237,
    prefix: 'cmr',
    created_at: '31/11/2020',
    updated_at: '2018/07/29',
    deleted_at: '2018/07/29'
  },
];

export { tableData };
