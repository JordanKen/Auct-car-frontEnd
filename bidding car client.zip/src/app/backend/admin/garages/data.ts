const tableData = [
  {
    id: 1,
    user_id: 2,
    merchant_key: '21231321354',
    site_url: 'url.url.com',
    success_link: 'succes.link.com',
    fail_link: 'fail.link.com',
    logo: 'iso/cmr',
    name: 'ecommerce 237',
    description: '....................',
    json_data: '',
    created_at: '31/11/2020',
    updated_at: '2018/07/29',
    currency_id: 9,
    thumb: 'string'
  },
  {
    id: 2,
    user_id: 3,
    merchant_key: '2123132135',
    site_url: 'url.url.com',
    success_link: 'succes.link.com',
    fail_link: 'fail.link.com',
    logo: 'iso/cmr',
    name: 'ecommerce 237',
    description: '...............',
    json_data: '',
    created_at: '31/11/2020',
    updated_at: '2018/07/29',
    currency_id: 7,
    thumb: 'string'
  },
];

export { tableData };
