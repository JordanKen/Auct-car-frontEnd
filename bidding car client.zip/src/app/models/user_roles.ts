export class User_roles{
  user_id: number;
  role_id: number;
  clear(){
    this.user_id = undefined;
    this.role_id = undefined;
  }
}
